public class Main {
    public static void main(String[] args) {
        Test bob = new Test();
        bob.run();
    }
}
