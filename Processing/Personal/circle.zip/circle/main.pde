import processing.sound.*;
SoundFile clunk;
SoundFile pipe;

Circle[] circles;
int numCircles = 20;

public void setup() {
  // size(400, 400);
  fullScreen();
  
  clunk = new SoundFile(this, "clunk.mp3");
  pipe = new SoundFile(this, "clunk2.mp3");
  
  circles = new Circle[numCircles];
  
  for(int i = 0; i < numCircles; i++) {
    circles[i] = generateCircle();
  }
}

public Circle generateCircle() {
    int x = randInt(0, width);
    int y = randInt(0, height);
    
    int r = randInt(0, 256);
    int g = randInt(0, 256);
    int b = randInt(0, 256);
    
    int age = randInt(20, 100);
    
    return new Circle(age, new float[]{r, g, b}, age, x, y);
}

public int randInt(int min, int max) {
  return min + (int) Math.floor(Math.random() * (max - min + 1));
}

public void draw() {
  background(0, 0, 0);
  
  for(int i = 0; i < circles.length; i++) {
    circles[i].show();
    circles[i].age();
    
    if(circles[i].getAge() >= circles[i].getMaxAge()) {
      if(randInt(0, 100) >= 99) {
        pipe.play();
      } else {
        clunk.play();
      }
      
      circles[i] = generateCircle();
    }
  }
  
  clear();
}
